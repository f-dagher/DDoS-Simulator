TO RUN THE PROGRAM:

Compile the three java files and run 
1) Server first
2) Node second
3) Coordinator third

Follow the instructions given by the Coordinator.

QUESTIONS:

The program may not work correctly if a string is entered instead of an integer when asked how many attacks is wanted.
Precondtions could have been added in order to ensure correctness, as well as cleaner code in terms of multiple helper classes.
